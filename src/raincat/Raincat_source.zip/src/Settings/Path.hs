module Settings.Path
    (dataPath) where

dataPath :: [Char]
dataPath = "../"
